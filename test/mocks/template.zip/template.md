# Subject
Password reset request

# Html
<div mc:edit="header">
    <p>*|FNAME|*,</p>
    <p>We received a request to reset the password associated with this e-mail address.</p>
</div>
<div mc:edit="main">
    <p>If you made this request, to reset your password using our secure server <a href="https://app.parkingmobility.com/forgotpassword/*|URL|*">please click here</a>.</p>
    <p>If you did not request to have your password reset you can safely ignore this email. Rest assured your customer account is safe.</p>
    <p>Parking Mobility will never e-mail you and ask you to disclose or verify your password or any other personal information. If you receive a suspicious e-mail with a link to update your account information, do not click on the link. Instead, please send us an email at support@parkingmobility.com.</p>
    <br/>
</div>
<div mc:edit="footer">
Accessibly yours,<br/>
The Parking Mobility Team
</div>

# Text


# Labels
* changepassword

# From Email
support@parkingmobility.com

# From Name
Parking Mobility

